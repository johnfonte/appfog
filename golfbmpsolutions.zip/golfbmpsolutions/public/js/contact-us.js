$(document).ready(function(){
	$('#clearButton').click(function() {
		$('#name').val('');
		$('#from').val('');
		$('#message').val('');
		$('#name').focus();
	});
});
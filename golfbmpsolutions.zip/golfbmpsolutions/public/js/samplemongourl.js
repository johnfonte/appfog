var mongo = {
"hostname":"yourhostname",
"port":yourport#,
"username":"user",
"password":"pass",
"name":"",
"db":"databasename"
};

exports.get_mongo_url = function(){
    mongo.hostname = (mongo.hostname || 'localhost');
    mongo.port = (mongo.port || 27017);
    mongo.db = (mongo.db || 'test');
    if(mongo.username && mongo.password){
        return "mongodb://" + mongo.username + ":" + mongo.password + "@" + mongo.hostname + ":" + mongo.port + "/" + mongo.db;
    }
    else{
        return "mongodb://" + mongo.hostname + ":" + mongo.port + "/" + mongo.db;
    }
};
mixpanel.track_forms("#emailForm", "Contact Us Form Submission");
function setContact(name) {
  $("select#to option")
    .each(function() { this.selected = (this.text == name)?"selected":""; });
  window.location = '#emailForm';
}

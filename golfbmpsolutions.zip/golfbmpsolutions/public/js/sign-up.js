$(document).ready(function() {
	$('#companyName').focus();
});
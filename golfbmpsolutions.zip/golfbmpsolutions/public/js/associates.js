$(document).ready(function() {
  $('#addAssociate').click(function() {
    $('#addAssociate').hide();
    $('#associateForm').show();
  });
  $('[name=cancel]').click(function() {
    $('#associateForm').hide();
    $('#associateForm').children('#name').val('');
    $('#associateForm').children('#email').val('');
    $('#addAssociate').show();
  });
  $('[name=undo]').click(function() {
    var form = $(this).parent().parent();
    form.find('[name=name]').val(form.find('[name=old_name]').val());
    form.find('[name=email]').val(form.find('[name=old_email]').val());
  });
  $('[name=reset]').click(function() {
    var form = $(this).parent().parent();
    form.find('[name=action]').val('reset');
  });
  $('[name=update]').click(function() {
    var form = $(this).parent().parent();
    form.find('[name=action]').val('update');
  });
  $('[name=associateForm]').bind('keypress keydown keyup', function(e){
     if(e.keyCode == 13) { e.preventDefault(); }
  });
});

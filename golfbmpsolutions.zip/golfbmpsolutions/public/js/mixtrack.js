mixpanel.track_links('#home', 'Home Page Link Clicked');
mixpanel.track_links('#about', 'About Page Link Clicked');
mixpanel.track_links('#bmps', 'BMPs Page Link Clicked');
mixpanel.track_links('#safety', 'Safety Page Link Clicked');
mixpanel.track_links('#nutrition', 'Nutrition Page Link Clicked');
mixpanel.track_links('#wildlife', 'Wildlife Page Link Clicked');
mixpanel.track_links('#stormwatermapping', 'Storm Water Mapping Page Link Clicked');
mixpanel.track_links('#contactus', 'Contact Us Page Link Clicked');

$(document).ready(function() {
  // $('#uploader').text("Drop MS Word or MS Excel Files Here").css({
  //             'backgroundColor': "#E0E0E0",
  //             'border': "1px dashed #666",
  //             'border-radius': "7px",
  //             'display': "inline-block",
  //             'width': "265px",
  //             'padding': "6px"
  //         }).hide();
  // $('#selectClient').hide();
  // $('#selectType').hide();
  // $('#selectMonth').hide();
  // $('#selectYear').hide();
  $('.report').hide();
  $('.invoice').hide();
  // $('#uploaded').css({
  //                     'display': "inline-block",
  //                     'width': "100px"
  //                   });
  // filepicker.setKey('A79CNiIOeRsvGMX97Tlsqz');
  // filepicker.makeDropPane($('#uploader')[0], {
  //   multiple: true,
  //   mimetypes: "application/vnd.openxmlformats-officedocument.wordprocessingml.document" 
  //           + ",application/msword"
  //           + ",application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  //   dragEnter: function() {
  //       $('#uploader').text("Drop to Upload").css({
  //           'backgroundColor': "#E0E0E0",
  //           'border': "1px solid #000",
  //           'border-radius': "7px",
  //           'display': "inline-block",
  //           'width': "265px",
  //           'padding': "6px"
  //       });
  //   },
  //   dragLeave: function() {
  //       $('#uploader').text("Drop MS Word or MS Excel Files Here").css({
  //           'backgroundColor': "#F6F6F6",
  //           'border': "1px dashed #666",
  //           'border-radius': "7px",
  //           'display': "inline-block",
  //           'width': "265px",
  //           'padding': "6px"
  //       });
  //   },
  //   onStart: function(files) {
  //     $('#uploaded').replaceWith('<div id="uploaded" class="progress progress-info progress-striped active" style="width: 870px; margin:10px 0;">'+
  //       '<div id="resultBar" class="bar" style="width: 20%">Uploading (20%)</div>'+
  //     '</div>');
  //   },
  //   onProgress: function(percentage) {
  //       $('#resultBar').attr('style', "width: "+(percentage*8)+"px");
  //       $('#resultBar').text("Uploading ("+percentage+"%)");
  //   },
  //   onSuccess: function(InkBlobs) {
  //     $('#uploaded').replaceWith('<div id="uploaded" class="progress progress-info progress-striped" style="width: 870px; margin:10px 0;">'+
  //       '<div id="resultBar" class="bar" style="width: 870px; text-align: center;">Finished!</div>'+
  //     '</div>');
  //       $('#uploader').text("Drop MS Word or MS Excel Files Here").css({
  //             'backgroundColor': "#E0E0E0",
  //             'border': "1px dashed #666",
  //             'border-radius': "7px",
  //             'display': "inline-block",
  //             'width': "265px",
  //             'padding': "6px"
  //         });
  //       for(var i=0; i<InkBlobs.length; i++) {
  //         $.post('/upload', {
  //             name: InkBlobs[i].filename,
  //             url: InkBlobs[i].url,
  //             mimetype: InkBlobs[i].mimetype,
  //             _csrf: $('#_csrf').text(),
  //             client: $('#selectClient').val(),
  //             type: $('#selectType').val(),
  //             month: $('#selectMonth').val(),
  //             year: $('#selectYear').val()
  //           })
  //         .done(function(data){
  //           //insert each uploaded file into page
  //         });
  //       }
  //   },
  //   onError: function(type, message) {
  //       $('#uploader').text('('+type+') '+ message);
  //   }
  // });
  $('.client').click(function() {
    var clientButton = $(this);
    var reportButton = $(this).siblings('.report');
    var invoiceButton = $(this).siblings('.invoice');
    var cancelButton = $(this).siblings('.cancel');
    clientButton.hide();
    reportButton.show();
    invoiceButton.show();
    cancelButton.show();
  });

  $('.cancel').click(function() {
    var cancelButton = $(this);
    var reportButton = $(this).siblings('.report');
    var invoiceButton = $(this).siblings('.invoice');
    var clientButton = $(this).siblings('.client');
    clientButton.show();
    reportButton.hide();
    invoiceButton.hide();
    cancelButton.hide();
  });

  // var postFileFunction = function() {
  //   var fileId = $(this).siblings('._id');
  //   var fileIdObject = $('#'+fileId);
  //   $.post('/file', {
  //     _id: fileId,
  //     client: fileIdObject.siblings('.client').val(),
  //     type: fileIdObject.siblings('.type').val(),
  //     month: fileIdObject.siblings('.month').val(),
  //     year: fileIdObject.siblings('.year').val(),
  //     _csrf: $('#_csrf').text()
  //   });
  // };

  // var postFileTimeout;
  // var postFileTimeoutFunction = function() {
  //   clearTimeout(postFileTimeout);
  //   postFileTimeout = setTimeout(postFileFunction, 500);
  // };

  // $('.month').change(postFileFunction);
  // $('.year').change(postFileFunction);
  // $('.client').keyup(postFileTimeoutFunction);
  // $('.type').keyup(postFileTimeoutFunction);
});

//vnd.openxmlformats-officedocument.wordprocessingml.document,application/msword,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet
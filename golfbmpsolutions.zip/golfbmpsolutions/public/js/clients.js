$(document).ready(function() {
  $('#addClient').click(function() {
    $('#addClient').hide();
    $('#clientForm').show();
  });
  $('[name=cancel]').click(function() {
    $('#clientForm').hide();
    $('#clientForm').children('#name').val('');
    $('#clientForm').children('#email').val('');
    $('#addClient').show();
  });
  $('[name=undo]').click(function() {
    var form = $(this).parent().parent();
    form.find('[name=name]').val(form.find('[name=old_name]').val());
    form.find('[name=email]').val(form.find('[name=old_email]').val());
  });
  $('[name=reset]').click(function() {
    var form = $(this).parent().parent();
    form.find('[name=action]').val('reset');
  });
  $('[name=update]').click(function() {
    var form = $(this).parent().parent();
    form.find('[name=action]').val('update');
  });
  $('[name=clientForm]').bind('keypress keydown keyup', function(e){
     if(e.keyCode == 13) { e.preventDefault(); }
  });
});
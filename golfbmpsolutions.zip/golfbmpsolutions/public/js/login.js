$(document).ready(function() {
	$('#navLogin').click(function() {
		$('#loginEmail').focus();
	});
	$('#cancelLogin').click(function() {
		$('.dropdown.open .dropdown-toggle').dropdown('toggle');
	});
	$('#signupForm').submit(function(event) {
		event.preventDefault();
    	$('#signupPass1').val(CryptoJS.SHA512($('#signupPass1').val()).toString());
    	$('#signupPass2').val(CryptoJS.SHA512($('#signupPass2').val()).toString());
    	$(this).unbind('submit').submit();
	});
	$('#loginForm').submit(function(event) {
		event.preventDefault();
		$('#loginPass').val(CryptoJS.SHA512($('#loginPass').val()).toString());
    	$(this).unbind('submit').submit();
	});
});

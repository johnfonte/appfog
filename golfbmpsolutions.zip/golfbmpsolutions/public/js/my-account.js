$(document).ready(function(){
	$('#resetAccount').click(function() {
		$('#accountName').val($('#oldAccountName').val());
		$('#accountEmail').val($('#oldAccountEmail').val());
		$('#accountOldPass').val('');
		$('#accountPass').val('');
	});
	$('#accountForm').submit(function(event) {
		if( !$("#accountOldPass").attr("disabled") && $("#accountOldPass").val() != '' && $("#accountOldPass").val().trim() != '') {
			$('#accountOldPass').val(CryptoJS.SHA512($('#accountOldPass').val()).toString());
		}
		if($("#accountPass").val() != '' && $("#accountPass").val().trim() != '') {
			$('#accountPass').val(CryptoJS.SHA512($('#accountPass').val()).toString());
		}
	});
});
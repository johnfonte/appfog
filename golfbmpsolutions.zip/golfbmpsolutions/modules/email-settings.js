module.exports = {

	host		: 'smtp.gmail.com',
	user 		: 'admin@golfbmpsolutions.com',
	password 	: 'G0lfBMPsolutions',
	sender		: 'Golf BMP Solutions <admin@golfbmpsolutions.com>'

}
var ES = require('./email-settings');
var EM = {};
module.exports = EM;

EM.server = require("emailjs/email").server.connect({

	host 	    : ES.host,
	user 	    : ES.user,
	password    : ES.password,
	ssl		    : true

});

EM.composeEmail = { };
EM.dispatchEmail = { };

EM.dispatchEmail["confirm"] = function(account)
{
	EM.server.send({
		from         : ES.sender,
		to           : account.email,
		subject      : 'Welcome to Golf BMP Solutions',
		text         : 'something went wrong... :(',
		attachment   : EM.composeEmail["confirm"](account)
	});
}

EM.composeEmail["confirm"] = function(o)
{
	var link = 'http://www.golfbmpsolutions.com/confirm?key='+o.key;
	var html = "<html><body>";
		html += "Hi "+o.name+",<br><br>";
		html += "Welcome to Golf BMP Solutions!<br>"
		html += "Your new user email is : <b>"+o.email+"</b><br><br>";
		html += "Confirm your <a href='"+link+"'>new account</a>.<br><br>";
		html += "Thanks,<br>";
		html += "Golf BMP Solutions<br><br>";
		html += "</body></html>";
	return  [{data:html, alternative:true}];
}

EM.dispatchEmail["contact-us"] = function(object)
{
	EM.server.send({
		from         : ES.sender,
		to           : 'admin@golfbmpsolutions.com',
		subject      : 'Golf BMP Solutions - Contact Form',
		text         : 'something went wrong... :(',
		attachment   : EM.composeEmail["contact-us"](object)
	});
}

EM.composeEmail["contact-us"] = function(o)
{
	var link = 'http://www.golfbmpsolutions.com/contact-us';
	var html = "<html><body>";
		html += "Hi!<br><br>";
		html += "The Contact Us Form on <a href='"+link+"'>Golf BMP Solutions</a> has been filled out!<br><br>";
		html += o.name+" sent you:<br><br>";
		html += o.message.replace(/\n/g, '<br />')+"<br><br>";
		html += "You can contact them at <a href='mailto:"+o.from+"'>"+o.from+"</a>.<br><br>";
		html += "Thanks,<br>";
		html += "Golf BMP Solutions<br><br>";
		html += "</body></html>";
	return  [{data:html, alternative:true}];
}

EM.dispatchEmail["reset"] = function(account)
{
	EM.server.send({
		from         : ES.sender,
		to           : account.email,
		subject      : 'Golf BMP Solutions - Password Reset',
		text         : 'something went wrong... :(',
		attachment   : EM.composeEmail["reset"](account)
	});
}

EM.composeEmail["reset"] = function(o)
{
	var link = 'http://www.golfbmpsolutions.com/reset?key='+o.key;
	var html = "<html><body>";
		html += "Hi "+o.name+",<br><br>";
		html += "Your password has been reset on <a href='http://www.golfbmpsolutions.com/'>Golf BMP Solutions</a>.<br><br>";
		html += "Change your password in the <a href='"+link+"'>My Account</a> section.<br><br>";
		html += "Thanks,<br>";
		html += "Golf BMP Solutions<br><br>";
		html += "</body></html>";
	return  [{data:html, alternative:true}];
}

EM.dispatchEmail["update"] = function(account)
{
    EM.server.send({
        from         : ES.sender,
        to           : account.email,
        subject      : 'Golf BMP Solutions - Account Update',
        text         : 'something went wrong... :(',
        attachment   : EM.composeEmail["update"](account)
    });
}

EM.composeEmail["update"] = function(o)
{
    var link = 'http://www.golfbmpsolutions.com/';
    var html = "<html><body>";
        html += "Hi "+o.name+",<br><br>";
        html += "Your account has been updated on <a href='"+link+"'>Golf BMP Solutions</a>.<br><br>";
        html += "Your user email is now : <strong>"+o.email+"</strong><br><br>";
        html += "Thanks,<br>";
        html += "Golf BMP Solutions<br><br>";
        html += "</body></html>";
    return  [{data:html, alternative:true}];
}
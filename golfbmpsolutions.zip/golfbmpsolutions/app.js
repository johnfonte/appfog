#!/bin/env node
// Golf BMP Solutions
// Written in Express on Node.js
// Author: John Fonte

var express     = require('express')
  , fs          = require('fs')
  , util        = require('util')
  , email       = require('emailjs')
  , mongoose    = require('mongoose')
  , os          = require('os')
  , path        = require('path')
  , moment      = require('moment')
  // , AM          = require('./modules/account-manager')
  , EM          = require('./modules/email-dispatcher')
  , ejs         = require('ejs')
  , _           = require('underscore');

moment().format();

var mongourl = require('./private/js/mymongourl').get_mongo_url();

var mongoDB = require('./models/allmodels.js');

var allowCrossDomain = function(req, res, next) {
    res.header('Access-Control-Allow-Origin', "*");
    res.header('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE');
    res.header('Access-Control-Allow-Headers', 'Content-Type');
};

var loggingOn = false;

var lg = function(text) {
    if(loggingOn) {
        console.log(text);
    }
};
/**
 *  Define the application.
 */
var GolfBMPApp = function() {

    //  Scope.
    var self = this;

    /*  ================================================================  */
    /*  Helper functions.                                                 */
    /*  ================================================================  */

    /**
     *  Set up server IP address and port # using env variables/defaults.
     */
    self.setupVariables = function() {
        //  Set the environment variables we need.
        self.ipaddress = (process.env.VCAP_APP_HOST || 'localhost');
        self.port      = (process.env.VCAP_APP_PORT || 3000);

        if (typeof self.ipaddress === "undefined") {
            //  Log errors but continue w/ 127.0.0.1
            console.warn('No internal IP variable, using 127.0.0.1 (localhost)');
            self.ipaddress = "127.0.0.1";
        }
    };

    self.mongooseConnection = function() {
        mongoose.connect(mongourl);
        mongoose.connection.on('error', console.error.bind(console, 'connection error:'));
    };

    self.populatePages = function() {
        self.allPages = [];
        mongoDB.getAllPages(function(err, data) {
            for(var i in data) {
                self.allPages[data[i].html] = data[i];
            }
        });

        self.pages = [];
        self.getPages("visitor");
        self.getPages("client");
        self.getPages("associate");
        self.getPages("owner");
        self.getPages("webadmin");

        self.sliders = [];
        self.getSliders("wildlife");
        self.getSliders("home");
        self.getSliders("nutrition");
    };

    self.getPages = function(type) {
        mongoDB.getPages(type, function(err, data) {
            self.pages[type] = data;
        });
    };

    self.getSliders = function(page) {
        mongoDB.getSliders(page, function(data) {
            if(data) {
                self.sliders[page] = data;
            } else {
                self.sliders[page] = false;
            }
        });
    };

    self.sendJSONMessageAndSuccess = function(res, message, success) {
        res.json({text: message, success: success});
    }

    self.setSessionMessageAndSuccess = function(req, message, success) {
        req.session.message = {};
        req.session.message.text = message;
        req.session.message.success = success;
        req.session.message.error = !success;
    }

    /**
     *  terminator === the termination handler
     *  Terminate server on receipt of the specified signal.
     *  @param {string} sig  Signal to terminate on.
     */
    self.terminator = function(sig){
        if (typeof sig === "string") {
           console.log('%s: Received %s - terminating app \'golfbmpsolutions\'...',
                       moment(), sig);
           process.exit(1);
        }
        console.log('%s: Node server stopped.', moment() );
    };

    /**
     *  Setup termination handlers (for exit and a list of signals).
     */
    self.setupTerminationHandlers = function(){
        //  Process on exit and signals.
        process.on('exit', function() { self.terminator(); });

        // Removed 'SIGPIPE' from the list - bugz 852598.
        ['SIGHUP', 'SIGINT', 'SIGQUIT', 'SIGILL', 'SIGTRAP', 'SIGABRT',
         'SIGBUS', 'SIGFPE', 'SIGUSR1', 'SIGSEGV', 'SIGUSR2', 'SIGTERM'
        ].forEach(function(element, index, array) {
            process.on(element, function() { self.terminator(element); });
        });
    };

    /*  ================================================================  */
    /*  App server functions (main app logic here).                       */
    /*  ================================================================  */

    /**
     *  Create the routing table entries + handlers for the application.
     */
    self.createRoutes = function() {
        self.get_routes = { };
        self.post_routes = { };

        //needs CSRF validation
        self.post_routes['/contact'] = function(req, res) {
            if(req.get('user-agent') == "" ||
                req.get('referer') == "" ||
                req.body.name == "" ||
                req.body.from == "" ||
                req.body.message == "") {
                self.setSessionMessageAndSuccess(req, "Your message has not been sent. Please fill out the form and try again.", false);
                res.redirect('/contact-us');
            } else {
                EM.dispatchEmail["contact-us"]({
                    name: req.body.name,
                    from: req.body.from,
                    message: req.body.message
                });
                self.setSessionMessageAndSuccess(req, "Your message has been sent. We will get back to you as soon as possible. Thank You!", true);
                res.redirect('/contact-us');
            }
        };

        self.post_routes['/add'] = function(req, res) {
            //hardcode pw for empty string
            mongoDB.addNewAccount({
                name    : req.body.name,
                nameKey : req.body.name.toLowerCase(),
                email   : req.body.email.toLowerCase(),
                pass    : req.body.pass,
                type    : req.body.type,
                valid   : false,
                deleted : false
            }, function(err, data) {
                if(err) {
                    self.setSessionMessageAndSuccess(req, err, false);
                } else {
                    EM.dispatchEmail["confirm"](data);
                    self.setSessionMessageAndSuccess(req, "The "+req.body.type+" has been added. They need to check their email for verification.", true);
                }
                res.redirect('/'+req.body.type+'s');
            });
        };

        self.post_routes['/slider'] = function(req, res) {
            params = req.body;
            id = req.body._id;
            delete params._id;
            delete params._csrf;
            delete params.update;
            mongoDB.updateSliderById(
                id,
                params,
                function(err, data) {
                    if(err) {
                        self.setSessionMessageAndSuccess(req, err, false);
                    } else {
                        self.setSessionMessageAndSuccess(req, "The slider has been updated.", true);
                    }
                    res.redirect('/sliders');
                })
        }

        self.post_routes['/update'] = function(req, res) {//write email for update (old/new)
            lg(req.body.action);
            if(req.body.action == 'update') {
                mongoDB.updateAccountByIdHash(
                {
                    idHash: req.body.idHash,
                    name: req.body.name,
                    nameKey: req.body.name.toLowerCase(),
                    email: req.body.email.toLowerCase()
                },
                function(err, data) {
                    if(err) {
                        self.setSessionMessageAndSuccess(req, err, false);
                    } else {
                        EM.dispatchEmail["update"](data);
                        self.setSessionMessageAndSuccess(req, "The "+req.body.type+" has been updated. They will receive an email regarding this action.", true);
                    }
                    res.redirect('/'+req.body.type+'s');
                });
            } else if(req.body.action == 'reset') {
                mongoDB.findAccountByEmail(
                req.body.email.toLowerCase(),
                function(err, data) {
                    if(err) {
                        self.setSessionMessageAndSuccess(req, err, false);
                    } else {
                        EM.dispatchEmail["reset"](data);
                        self.setSessionMessageAndSuccess(req, "Password Reset email sent.", true);
                    }
                    res.redirect('/'+req.body.type+'s');
                });
            }
        };

        self.post_routes['/account'] = function(req, res) {
            mongoDB.updateAccount({
                idHash: req.body.idHash,
                name: req.body.name,
                email: req.body.email,
                pass: req.body.pass,
                old_pass: req.body.old_pass
            }, function(err, data) {
                if(data) {
                    res.clearCookie('email', { path: '/' });
                    res.clearCookie('pass', { path: '/' });
                    delete req.session.user;
                    req.session.user = data;
                    self.setSessionMessageAndSuccess(req, "Your account info was updated.", true);
                } else {
                    self.setSessionMessageAndSuccess(req, "There was a problem updating your account. Please try again.", false);
                }
                res.redirect('/my-account');
            });
        };

        self.post_routes['/login'] = function(req, res) {
            mongoDB.manualLogin({
                email: req.body.email,
                pass: req.body.pass
            }, function(err, data) {
                if(err) {
                    self.setSessionMessageAndSuccess(req, err, false);
                    res.redirect('/home');
                } else {
                    lg("remember me: " + req.body.remember);
                    if(req.body.remember) {
                        res.cookie('email', data.email);
                        res.cookie('pass', data.pass);
                    }
                    req.session.user = data;
                    res.redirect('/' + self.pages[req.session.user.type][0].html);
                }
            });
        };

        self.post_routes['/logout'] = function(req, res) {
            res.clearCookie('email', { path: '/' });
            res.clearCookie('pass', { path: '/' });
            delete req.session.user;
            self.setSessionMessageAndSuccess(req, "You have been safely logged out.", true);
            res.redirect('/home');
        };

        self.post_routes['/signup'] = function(req, res) {
            if(req.body.name != '' && req.body.email != '' && req.body.pass1 != '' && req.body.pass2 != '') {
                mongoDB.addNewAccount({
                    name    : req.body.name,
                    nameKey : req.body.name.toLowerCase(),
                    email   : req.body.email.toLowerCase(),
                    pass1    : req.body.pass1,
                    pass2    : req.body.pass2,
                    type    : 'client',
                    valid   : false,
                    deleted : false
                }, function(err, data) {
                    if(err) {
                        self.setSessionMessageAndSuccess(req, err, false);
                        res.redirect('/sign-up');
                    } else {
                        EM.dispatchEmail["confirm"](data);
                        self.setSessionMessageAndSuccess(req, "Your signup has been received. Please check your email for verification.", true);
                        res.redirect('/home');
                    }
                });
            } else {
                self.setSessionMessageAndSuccess(req, err, false);
                res.redirect('/sign-up');
            }
        };

        self.get_routes['/hash'] = function (req, res) {
            mongoDB.hashExistingAccounts(function() {
                self.setSessionMessageAndSuccess(req, "Emails have been hashed.", true);
                res.redirect('/home');
            });
        };

        self.get_routes['/confirm'] = function (req, res) {
            lg("confirm account");
            mongoDB.confirmAccount(req.param('key'), function(o) {
                if(o) {
                    lg(o);
                    mongoDB.manualLogin({
                        email: o.email,
                        pass: o.pass
                    }, function(err, data) {
                        if(err) {
                            self.setSessionMessageAndSuccess(req, err, false);
                            res.redirect('/home');
                        } else {
                            self.setSessionMessageAndSuccess(req, "Please set a new password. ", true);
                            res.cookie('email', data.email);
                            res.cookie('pass', data.pass);
                            lg(data);
                            req.session.user = data;
                            res.redirect('/my-account');
                        }
                    });
                }
            });
        };

        self.post_routes['/upload'] = function (req, res) {
            req.body.addedby = req.session.user.name;
            mongoDB.addFile(req.body);
            res.redirect('/upload');
        };

        self.post_routes['/delete'] = function (req, res) {
            req.body.addedby = req.session.user.name;
            mongoDB.deleteFile(req.body);
            res.redirect('/upload');
        };

        self.get_routes['*.zip'] = function(req, res) {
            res.download(__dirname + '/downloads/' + req.url, req.url);
        }

        self.get_routes['/*'] = function(req, res) {
            lg(req.url);
            req.url = (req.url == '/')?'/home':req.url;
            req.url = req.url.split('/')[1].split('.')[0];
            var page = self.allPages[req.url];
            res.locals.title = page.title;
            res.locals.token = req.session._csrf;
            res.locals.message = (req.session.message)? req.session.message : false;
            delete req.session.message;
            res.locals.newUser = (req.session.user && !req.session.user.pass)? true : false;
            res.locals.email = (req.session.user && req.session.user.email)? req.session.user.email : false;
            res.locals.uname = (req.session.user && req.session.user.name)? req.session.user.name : false;

            function render() {
                res.setHeader('Content-Type', 'text/html; charset=utf8');
                res.render(req.url);
            }

            function setActivePage(index) {
                for(var i in res.locals.pages) {
                    res.locals.pages[i].class = (i==index)?"active":"";
                }
            }

            if(page.restricted && page[req.session.user.type+"Index"] != null && page[req.session.user.type+"Index"] > -1) {
                res.locals.pages = self.pages[req.session.user.type];
                setActivePage(page[req.session.user.type+"Index"]);
                if(req.url == 'upload') {
                    mongoDB.getClients(function(err, data) {
                        res.locals.clients = [];
                        for(var i=0; i<data.length; i++) {
                            res.locals.clients[i] = data[i].name;
                        }
                        mongoDB.getFiles({}, function(err, data) {
                            res.locals.files = (err)? false : data;
                            render();
                        });
                    });
                } else if(req.url == 'reports') {
                    mongoDB.getReports(req.session.user, function(err, data) {
                        res.locals.files = (err)? false : data;
                        render();
                    });
                } else if(req.url == 'invoices') {
                    mongoDB.getInvoices(req.session.user, function(err, data) {
                        res.locals.files = (err)? false : data;
                        render();
                    });
                } else if(req.url == 'sliders') {
                    mongoDB.getAllSliders(function(err, data) {
                        res.locals.sliders = (err)? false : data;
                        render();
                    });
                } else if(req.url == 'my-account') {
                    mongoDB.getAccountByEmail(req.session.user.email, function(data) {
                        res.locals.account = data;
                        render();
                    });
                } else if(req.url == 'associates') {
                    mongoDB.getAssociates(function(err, data) {
                        res.locals.associates = data;
                        render();
                    });
                } else if(req.url == 'clients') {
                    mongoDB.getClients(function(err, data) {
                        res.locals.clients = data;
                        render();
                    });
                } else {
                    render();
                }
            } else if(page.visitorIndex > -1) {
                res.locals.pages = self.pages['visitor'];
                setActivePage(page.visitorIndex);
                res.setHeader('Content-Type', 'text/html; charset=utf8');
                res.locals.items = self.sliders[req.url];
                render();
            } else if(page.simpleIndex > -1) {
                res.setHeader('Content-Type', 'text/html; charset=utf8');
                res.locals.pages = self.pages['visitor'];
                setActivePage(-1);
                render();
            } else if(page.restricted) {
                self.setSessionMessageAndSuccess(req, "That page is not accessible.", false);
                res.redirect('/my-account');
            }
        }

    }; 

    self.authenticate = function(req, res, next) {
        var url = (req.url == '/')?'/home':req.url;
        url = url.split('/')[1].split('.')[0];
        var page = self.allPages[url];

        lg('auth func');
        lg('trying ' + req.url);
        if(page && page.restricted) {
            lg('page restricted');
            if(req.session.user 
                && req.session.user.idHash
                && (req.session.user.type == 'client' || 
                    req.session.user.type == 'associate' ||
                    req.session.user.type == 'owner' ||
                    req.session.user.type == 'webadmin')) {
                next(); //authentication successful
                lg('auth success');
            } else if(req.cookies.email && req.cookies.pass) { //autologin because the page is protected
                lg('email+pass cookies');
                    mongoDB.autoLogin(req.cookies.email, req.cookies.pass, function(o) {
                        lg('autologin');
                        if(!o){
                            //need to log in
                            //TODO set redirect for next attempt
                            self.setSessionMessageAndSuccess(req, "Login Failed.", false);
                            res.redirect('/home');
                        } else {
                            //redirect to attempted page or to first page
                            req.session.user = o;
                            if(req.session.redirect) {
                                lg('redir logic success');
                                var redirect = req.session.redirect;
                                delete req.session.redirect;
                                res.redirect(redirect);
                            } else {
                                res.redirect('/my-account');
                            }
                        }
                    });
            } else {
                lg('redir home');
                res.redirect('/home');
            }
        } else if(page && (page.visitorIndex > -1
                || page.simpleIndex > -1)) {
            next();
        } else {
            lg('redir home2');
            res.redirect('/home');
        }
    };


    /**
     *  Initialize the server (express) and create the routes and register
     *  the handlers.
     */
    self.initializeServer = function() {
        self.createRoutes();
        self.app = express();
        self.app.engine('ejs', require('ejs-locals'));
        self.app.set('view engine', 'ejs');
        self.app.set('view options', { layout: "boilerplate" });
        self.app.set('views', __dirname + '/templates');
        self.app.use(express.bodyParser());
        self.app.use(express.methodOverride());
        self.app.use(express.compress());
        self.app.use(express.favicon( __dirname + '/favicon.ico'));
        self.app.use(express.static(path.join(__dirname, 'public')));
        self.app.use(express.cookieParser(require(__dirname + '/private/js/mysecretkey').secretKey));
        self.app.use(express.cookieSession());
        self.app.use(express.csrf());
        // self.app.enableViewRouting();
        // self.app.use(allowCrossDomain);

        //  Add handlers for the app (from the routes).
        for(var r in self.post_routes) {
            self.app.post(r, self.post_routes[r]);
            lg(r);
        }

        // self.app.get('/hash', self.get_routes['/hash']);
        self.app.get('/confirm', self.get_routes['/confirm']);
        self.app.get('/reset', self.get_routes['/confirm']);
        self.app.get('*.zip', self.get_routes['*.zip']);
        self.app.get('/*', self.authenticate, self.get_routes['/*']);
    
    };


    /**
     *  Initializes the sample application.
     */
    self.initialize = function() {
        self.setupVariables();
        self.mongooseConnection();
        self.populatePages();
        self.setupTerminationHandlers();

        // Create the express server and routes.
        self.initializeServer();
    };


    /**
     *  Start the server (starts up the sample application).
     */
    self.start = function() {
        //  Start the app on the specific interface (and port).
        self.app.listen(self.port, self.ipaddress, function() {
            console.log('%s: Node server started on %s:%d ...',
                        moment(), self.ipaddress, self.port);
        });
    };

};   /*  End Application.  */

/**
 *  main():  Main code.
 */
var app = new GolfBMPApp();
app.initialize();

app.start();

// allmodels.js


var mongoose	= require('mongoose')
  , Schema		= mongoose.Schema
  , ObjectId	= Schema.ObjectId
  , moment    = require('moment')
  , sha512    = require('js-sha512')
  , securitySettings = require('./../modules/security-settings');

var loggingOn = false;

var lg = function(text) {
    if(loggingOn) {
        console.log(text);
    }
};

var PageSchema = new Schema({
    title			      : String
  , html            : String
  , visitorIndex    : Number
  , simpleIndex	    : Number
  , clientIndex     : Number
  , associateIndex  : Number
  , ownerIndex		  : Number
  , webadminIndex	  : Number
  , restricted      : Boolean
  , parent_start    : Boolean
  , parent_end      : Boolean
})
  , Page           = mongoose.model("Page", PageSchema);

var ViewSchema = new Schema({
		_id		: ObjectId
	  , name	: String
})
  , View = mongoose.model("View", ViewSchema);

var SliderSchema = new Schema({
    title     : String
  , page      : String
  , file      : String
  , fileName  : String
  , link      : String
  , linkTitle : String
  , lead      : String
  , index     : Number
})
  , Sliders = mongoose.model("Sliders", SliderSchema);

var AccountSchema = new Schema({
    _id     : ObjectId
  , idHash  : String
  , name    : String
  , nameKey : String
  , email   : String
  , pass    : String
  , type    : String
  , key     : String
  , deleted : Boolean
})
  , Account = mongoose.model("Account", AccountSchema);

var FileSchema = new Schema({
    _id       : ObjectId
  , name      : String
  , url       : String
  , fileType  : String
  , client    : String
  , addedBy   : String
  , month     : Number
  , year      : Number
  , type      : String
  , deleted   : Boolean
})
  , File = mongoose.model("File", FileSchema);

exports.getClients = function(callback) {
  var accountObject = Account.find();
  accountObject = accountObject.where('type').equals('client');
  accountObject = accountObject.where('deleted').equals(false);
  accountObject.exec(function(err, data) {
    if(err) {
      callback("No Clients Found.");
    } else {
      callback(null, data);
    }
  });
};

exports.addAssociate = function(params, callback) {
  var accountObject = Account.find();
  if(params.name)
    accountObject = accountObject.where('name').equals(params.name);
  if(params.email)
    accountObject = accountObject.where('email').equals(params.email);
};

exports.getAssociates = function(callback) {
  var accountObject = Account;
  accountObject = accountObject.where('type').equals('associate');
  accountObject = accountObject.where('deleted').equals(false);
  accountObject.exec(function(err, data) {
    if(err) {
      callback("No Associates Found.");
    } else {
      callback(null, data);
    }
  });
};

exports.getAllSliders = function(callback) {
  var slidersObject = Sliders.find();
  slidersObject.exec(function(err, data) {
    if(err) {
      callback("No Sliders Found.");
    } else {
      callback(null, data);
    }
  });
};

exports.findAccountById = function(idHash, callback) {
  Account.findOne({idHash:idHash}, function(e, o){
    if(e) {
    } else {
      o.pass = '';
      o.save(callback);
    }
  });
};

exports.findAccountByEmail = function(email, callback) {
  Account.findOne({email:email}, function(e, o){
    if(e) {
    } else {
      o.pass = '';
      o.save(callback);
    }
  });
};

exports.updateAccountById = function(id, params, callback) {
  Account.findByIdAndUpdate(id, params, callback);
};

exports.updateSliderById = function(id, params, callback) {
  Sliders.findByIdAndUpdate(id, params, callback);
};

exports.updateAccountByIdHash = function(newData, callback) {
  Account.findOne({idHash:newData.idHash}, function(e, o){
    if(e) {
      //
    } else {
      o.name    = (o.name != newData.name && newData.name.trim() != '')? newData.name : o.name;
      o.nameKey = o.name.toLowerCase();
      o.email   = (o.email != newData.email.toLowerCase() && newData.email.trim() != '')? newData.email.toLowerCase() : o.email;
      o.save(callback);
    }
  });
}

exports.addFile = function(file) {
  newFile = new File({
    name      : file.name,
    url       : file.url,
    fileType  : file.filetype,
    client    : file.client,
    addedBy   : file.addedby,
    month     : file.month,
    year      : file.year,
    type      : file.type,
    deleted   : false
  });
  newFile.save(function(err, data){

  });
};

exports.deleteFile = function(file) {
  File.findByIdAndUpdate(file._id, { $set: { deleted: true } },function(err, obj) {
    if (err) console.log(err);
    if (!obj) console.log('Cannot save.');
  });
}

exports.getFiles = function(params, callback) {
  var fileObject = File.find();
  fileObject = fileObject.where('deleted').equals(false);
  if(params.name)
      fileObject = fileObject.where('client').equals(params.name);
  if(params.type)
      fileObject = fileObject.where('type').equals(params.type);
  if(params.month)
      fileObject = fileObject.where('month').equals(params.month);
  if(params.year)
      fileObject = fileObject.where('year').equals(params.year);
  fileObject = fileObject.sort('-month -year name');
  fileObject.exec(function(err, data) {
    lg(data);
    if(err || data.length < 1) {
      callback("No Files.");
    } else {
      callback(null, data);
    }
  });
}

exports.getReports = function(params, callback) {
  var fileObject = File.where('type').equals('report');
  if(params.name){
      fileObject = fileObject.where('client').equals(params.name)
  }
  fileObject = fileObject.sort('month, year');
  fileObject.exec(function(err, data) {
    lg(data);
    if(err || data.length < 1) {
      callback("No Reports.");
    } else {
      callback(null, data);
    }
  });
};

exports.getInvoices = function(params, callback) {
  var fileObject = File.where('type').equals('invoice');
  fileObject = fileObject.where('deleted').equals(false);
  if(params.name){
      fileObject = fileObject.where('client').equals(params.name);
  }
  fileObject = fileObject.sort('month, year');
  fileObject.exec(function(err, data) {
    lg(data);
    if(err || data.length < 1) {
      callback("No Invoices.");
    } else {
      callback(null, data);
    }
  });
};

exports.getAllPages = function(callback) {
  Page.find().exec(callback);
};

exports.getPages = function(type, callback) {
    var pagesObject = Page;
    var typeString = type + "Index";
    pagesObject = pagesObject.where(typeString).gt(-1);
    pagesObject = pagesObject.sort(typeString);
    pagesObject.exec(callback);
};

exports.getSliders = function(page, callback) {
  Sliders.find({page: page})
  .sort({index: 1})
  .exec(function(err, data) {
    if(err) {
      callback(false);
    } else {
      callback(data);
    }
  });
};


/* login validation methods */

exports.autoLogin = function(email, pass, callback)
{
  Account.findOne({email:email.toLowerCase()}, function(e, o) {
    if (o){
      o.pass == pass ? callback(o) : callback(null);
    } else{
      callback(null);
    }
  });
}

exports.manualLogin = function(login, callback)
{
  var errorString = "That email address or password is incorrect."
  Account.findOne(
    {
      email: login.email.toLowerCase(),
      pass: login.pass
    },
    function(e, o) {
      if (o == null){
        callback(errorString);
      } else{
        callback(null, o);
      }
  });
}

/* record insertion, update & deletion methods */

exports.addNewAccount = function(newData, callback)
{
  if(newData.pass1 !== newData.pass2) {
    callback('Passwords do not match.');
  } else {
    Account.findOne({nameKey:newData.name.toLowerCase()}, function(e, o) {
      if (o){
        callback('That name is taken.');
      } else{
        Account.findOne({email:newData.email.toLowerCase()}, function(e, o) {
          if (o){
            callback('That email address is taken.');
          } else{
            newAccount = new Account(newData);
            newAccount.idHash = sha512(newAccount.email.toLowerCase()+securitySettings.secretKey);
            newAccount.key = sha512(newAccount.email.toLowerCase()+securitySettings.salt);
            newAccount.pass = '';
            newAccount.save(function(err, data){
            });
            callback(null, newAccount);
          }
        });
      }
    });
  }
}

exports.hashExistingAccount = function (email, callback) {
  Account.findOne({email:email.toLowerCase()}, function(e, o) {
    if(e) {} else {
      o.idHash = sha512(email+securitySettings.secretKey);
      o.save(callback);
    }
  });
}

exports.hashExistingAccounts = function (callback) {
  Account.find(function(e, o) {
    if(e) {} else {
      for(var i in o) {
        o[i].key = sha512(o[i].email.toLowerCase()+securitySettings.salt);
        o[i].save();
      }
      callback();
    }
  });
}


exports.updateAccount = function(newData, callback)
{
  Account.findOne({idHash:newData.idHash}, function(e, o){
    if(e) {
      //
    } else if((newData.old_pass && newData.old_pass.trim() != '' && newData.pass.trim() == '') || 
              (o.pass && o.pass != newData.old_pass && newData.pass.trim() != '')) {
      callback();
    } else {
      if(o.pass == '') {
        o.key = sha512(o.key+securitySettings.salt);
        // only overwrite key when it has been used!!
      }
      o.name    = (o.name != newData.name && newData.name.trim() != '')? newData.name : o.name;
      o.nameKey = o.name.toLowerCase();
      o.email   = (o.email != newData.email.toLowerCase() && newData.email.trim() != '')? newData.email.toLowerCase() : o.email;
      o.pass    = (newData.pass.trim() != '')? newData.pass : o.pass;
      o.save(callback);
    }
  });
}

exports.updatePassword = function(email, newPass, callback)
{
  Account.findOne({email:email.toLowerCase()}, function(e, o){
    if (e){
      callback(e, null);
    } else{
      Account.save(o, {safe: true}, callback);
    }
  });
}

/* account lookup methods */

exports.deleteAccount = function(id, callback)
{
  Account.remove({_id: getObjectId(id)}, callback);
}

exports.getAccountByEmail = function(email, callback)
{
  Account.findOne({email:email.toLowerCase()}, function(e, o){ callback(o); });
}

exports.validateResetLink = function(email, passHash, callback)
{
  Account.find({ $and: [{email:email.toLowerCase(), pass:passHash}] }, function(e, o){
    callback(o ? 'ok' : null);
  });
}

exports.getAllRecords = function(callback)
{
  Account.find().toArray(
    function(e, res) {
    if (e) callback(e)
    else callback(null, res)
  });
};

exports.delAllRecords = function(callback)
{
  Account.remove({}, callback); // reset Account collection for testing //
}

/* auxiliary methods */

var getObjectId = function(id)
{
  return Account.db.bson_serializer.ObjectID.createFromHexString(id)
}

var findById = function(id, callback)
{
  Account.findOne({_id: getObjectId(id)},
    function(e, res) {
    if (e) callback(e)
    else callback(null, res)
  });
};


var findByMultipleFields = function(a, callback)
{
// this takes an array of name/val pairs to search against {fieldName : 'value'} //
  Account.find( { $or : a } ).toArray(
    function(e, results) {
    if (e) callback(e)
    else callback(null, results)
  });
}

exports.confirmAccount = function(key, callback)
{
  Account.findOne({
    key:key
  }, 
  function(e, o){
    if (o){
      callback(o);
    } else {
      callback();
    }
  });
}
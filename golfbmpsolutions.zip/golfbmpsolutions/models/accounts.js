//accounts.js

(function(){

  module.exports = function(mongoose, Schema) {

	    var Accounts = new Schema({
	        email	: String
	      , pass	: String
	      , type	: String
	      , name	: String
	      , valid	: Boolean
	    });

	    mongoose.model("Accounts", Accounts);

	};

})();
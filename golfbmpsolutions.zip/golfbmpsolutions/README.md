golfbmpsolutions
================

Golf BMP Solutions node express server.

Uses Bootstrap css/js

Node parts:
express
fs
mongoose
mustache
nodemon

Other credits:
braitsch/node-login
felixge/node-dateformat
